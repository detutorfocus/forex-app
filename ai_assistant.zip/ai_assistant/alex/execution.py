# ai_assistant/alex/execution.py
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, Optional


@dataclass
class TradeIntent:
    symbol: str
    timeframe: str
    side: str          # "BUY" | "SELL"
    volume: float
    entry: float
    sl: float
    tp: float
    comment: str = "Alex guarded execution"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _pick(d: Dict[str, Any], *keys: str, default=None):
    for k in keys:
        if k in d and d[k] is not None:
            return d[k]
    return default


def build_trade_intent(
    decision: Dict[str, Any],
    *,
    symbol: str,
    timeframe: str,
    default_volume: float = 0.01,
) -> Optional[TradeIntent]:
    """
    Build an executable intent ONLY if the deterministic engine produced a valid plan.
    Works whether your plan sits in decision["plan"] or decision["raw"]["plan"].
    """
    if not isinstance(decision, dict):
        return None

    action = str(decision.get("action", "")).upper()

    # Only allow intent when action is ENTER/BUY/SELL (adjust if your engine uses different action words)
    if action not in {"ENTER", "BUY", "SELL"}:
        return None

    raw = decision.get("raw") if isinstance(decision.get("raw"), dict) else {}
    plan = decision.get("plan") if isinstance(decision.get("plan"), dict) else raw.get("plan")
    if not isinstance(plan, dict):
        return None

    side = str(_pick(plan, "side", "direction", default=action)).upper()
    if side not in {"BUY", "SELL"}:
        return None

    entry = _pick(plan, "entry", "entry_price")
    sl = _pick(plan, "sl", "stop_loss")
    tp = _pick(plan, "tp", "take_profit")

    if entry is None or sl is None or tp is None:
        return None

    volume = _pick(plan, "volume", default_volume)
    comment = _pick(plan, "comment", default="Alex guarded execution")

    try:
        return TradeIntent(
            symbol=symbol,
            timeframe=timeframe,
            side=side,
            volume=float(volume),
            entry=float(entry),
            sl=float(sl),
            tp=float(tp),
            comment=str(comment),
        )
    except Exception:
        return None
