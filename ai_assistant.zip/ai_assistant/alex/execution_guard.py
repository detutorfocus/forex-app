# ai_assistant/alex/execution_guard.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

from django.conf import settings


@dataclass
class ExecutionGuardResult:
    allowed: bool
    reason: str
    meta: Dict[str, Any]


def _tf_bucket(tf: str) -> str:
    tf = (tf or "").strip().upper()
    # Fast / short term
    if tf in {"M1", "M2", "M3", "M5", "M10", "M15"}:
        return "FAST"
    # Medium
    if tf in {"M20", "M30", "H1", "H2", "H3", "H4"}:
        return "MEDIUM"
    # Long
    return "LONG"


def _rules_for_bucket(bucket: str) -> Dict[str, Any]:
    """
    Auto assign confirmation behavior based on timeframe bucket.
    You can tune these defaults later in settings.
    """
    defaults = {
        "FAST":   {"require_confirmed": True,  "min_confidence": 85},
        "MEDIUM": {"require_confirmed": True,  "min_confidence": 80},
        "LONG":   {"require_confirmed": False, "min_confidence": 75},
    }
    return defaults.get(bucket, defaults["MEDIUM"])


def check_execution_safety(
    *,
    timeframe: str,
    decision: Dict[str, Any],
    auto_trade_enabled: bool,
) -> ExecutionGuardResult:
    """
    Final server-side gate before ANY execution (STRICT + deterministic).
    """

    enabled = bool(getattr(settings, "ALEX_EXECUTION_ENABLED", False))
    mode = str(getattr(settings, "ALEX_EXECUTION_MODE", "PAPER")).upper()

    if not enabled:
        return ExecutionGuardResult(False, "execution_disabled_globally", {"mode": mode})

    if mode not in {"PAPER", "LIVE"}:
        return ExecutionGuardResult(False, "invalid_execution_mode", {"mode": mode})

    # If LIVE mode, you must explicitly enable auto-trade per request/user
    if mode == "LIVE" and not auto_trade_enabled:
        return ExecutionGuardResult(False, "live_mode_but_auto_trade_off", {"mode": mode})

    bucket = _tf_bucket(timeframe)
    rules = _rules_for_bucket(bucket)

    require_confirmed: bool = bool(getattr(settings, "ALEX_CONFIRM_REQUIRED", rules["require_confirmed"]))
    min_confidence: int = int(getattr(settings, "ALEX_EXECUTION_MIN_CONFIDENCE", rules["min_confidence"]))

    action = str(decision.get("action", "WAIT")).upper()
    status = str(decision.get("status", "")).upper()

    # Must be OK decision before execution
    if status != "OK":
        return ExecutionGuardResult(False, "decision_not_ok", {"bucket": bucket, "mode": mode})

    # Only BUY/SELL can execute
    if action not in {"BUY", "SELL"}:
        return ExecutionGuardResult(False, "not_an_executable_action", {"action": action})

    # Must have zones for a trade
    zones = decision.get("zones") or []
    if not zones:
        return ExecutionGuardResult(False, "trade_without_zones", {"action": action})

    confidence = decision.get("confidence")
    try:
        confidence_i = int(confidence) if confidence is not None else 0
    except Exception:
        confidence_i = 0

    if confidence_i < min_confidence:
        return ExecutionGuardResult(
            False,
            "confidence_too_low",
            {"confidence": confidence_i, "min_confidence": min_confidence, "bucket": bucket},
        )

    # Optional “confirmed only” (your confirmation style)
    is_confirmed = bool(decision.get("confirmed", False))
    if require_confirmed and not is_confirmed:
        return ExecutionGuardResult(
            False,
            "confirmation_required",
            {"bucket": bucket, "require_confirmed": True},
        )

    return ExecutionGuardResult(
        True,
        "ok",
        {
            "mode": mode,
            "bucket": bucket,
            "min_confidence": min_confidence,
            "require_confirmed": require_confirmed,
        },
    )
