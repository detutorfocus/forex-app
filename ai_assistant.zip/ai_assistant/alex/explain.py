def build_explain_prompt(payload: dict) -> list[dict]:
    # payload is the deterministic decision dict
    raw = payload.get("raw", {})
    best = raw.get("best_zone", {})
    return [
        {"role": "system", "content": (
            "You are Alex, a trading assistant. You ONLY explain the deterministic decision. "
            "Never change action/confidence/entry/confirmation. "
            "Write clear chart feedback: zone, rejection, why WAIT/ENTER."
        )},
        {"role": "user", "content": (
            f"Symbol: {payload.get('symbol')}\n"
            f"Timeframe: {payload.get('timeframe')}\n"
            f"Action: {payload.get('action')}\n"
            f"Confidence: {payload.get('confidence')}\n"
            f"Confirmation: {payload.get('confirmation')}\n"
            f"Entry: {payload.get('entry_price')}\n"
            f"Zone: {best}\n"
            f"Other context: {raw}\n\n"
            "Explain what's happening and why this action is chosen. "
            "If WAIT, say what confirmation is missing. Keep it concise."
        )},
    ]
