# ai_assistant/alex/guard.py
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple


# Words that usually indicate the LLM is trying to "trade" instead of explain.
TRADE_LANGUAGE = re.compile(
    r"\b(buy|sell|long|short|entry|enter|open a trade|take profit|tp|stop loss|sl|risk[: ]|position size|leverage)\b",
    re.IGNORECASE,
)

# Words that often indicate invented certainty / structure
INVENTED_STRUCTURE = re.compile(
    r"\b(strong zone|clear zone|confirmed zone|supply zone|demand zone|breakout confirmed|trend reversal confirmed)\b",
    re.IGNORECASE,
)

# If engine says "no candles", Alex must not pretend it analyzed price action.
CANDLE_ANALYSIS = re.compile(
    r"\b(price action|candles show|market structure|momentum|volatility|wick|engulf|order block)\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class GuardResult:
    ok: bool
    reason: str
    payload: Optional[Dict[str, Any]] = None


def _safe_json_loads(s: str) -> Optional[Dict[str, Any]]:
    try:
        obj = json.loads(s)
        if isinstance(obj, dict):
            return obj
        return None
    except Exception:
        return None


def _contains_number_in_text(num: Any, text: str) -> bool:
    """
    Prevent Alex from inventing numbers.
    If engine provides a confidence like 0.62, Alex must not say 0.90.
    We'll only do a light check: if Alex mentions a % or decimal,
    it must match the engine confidence string if present.
    """
    try:
        if num is None:
            return True
        # normalize engine confidence to string forms
        f = float(num)
        # e.g. 0.62 -> "0.62" and "62%"
        s_dec = f"{f:.2f}"
        s_pct = f"{int(round(f * 100))}%"
        # If Alex mentions any % or decimal-like confidence, require match
        mentioned_pct = re.search(r"\b\d{1,3}\s?%\b", text)
        mentioned_dec = re.search(r"\b0\.\d+\b", text)
        if not mentioned_pct and not mentioned_dec:
            return True
        return (s_dec in text) or (s_pct in text)
    except Exception:
        return True


def validate_alex_output(decision: Dict[str, Any], llm_text: str) -> GuardResult:
    """
    Validates the LLM output against engine decision.
    Enforces action lock + blocks hallucinated trade advice.
    Expectation: llm_text is JSON string with a top-level dict.
    """
    action = str(decision.get("action", "")).upper().strip()
    reason = str(decision.get("reason") or decision.get("user_message") or "")

    parsed = _safe_json_loads(llm_text)
    if not parsed:
        return GuardResult(ok=False, reason="LLM did not return valid JSON.")

    explanation = str(parsed.get("explanation", "")).strip()
    if not explanation:
        return GuardResult(ok=False, reason="LLM JSON missing 'explanation'.")

    # --- Action lock rules ---
    # If action is WAIT, Alex must not use trade language.
    if action == "WAIT" and TRADE_LANGUAGE.search(explanation):
        return GuardResult(ok=False, reason="Trade language not allowed when action=WAIT.")

    # If engine says no candles, Alex must not talk about candle/price-action analysis.
    if "no candles" in reason.lower() and CANDLE_ANALYSIS.search(explanation):
        return GuardResult(ok=False, reason="Candle analysis not allowed when engine reports no candles.")

    # If engine says no zones, Alex must not claim zones are present/strong/confirmed.
    if "no valid zones" in reason.lower() and INVENTED_STRUCTURE.search(explanation):
        return GuardResult(ok=False, reason="Zone claims not allowed when engine reports no valid zones.")

    # Confidence integrity
    conf = decision.get("confidence", None)
    if not _contains_number_in_text(conf, explanation):
        return GuardResult(ok=False, reason="LLM confidence mention does not match engine confidence.")

    return GuardResult(ok=True, reason="OK", payload=parsed)


def fallback_explanation(decision: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deterministic safe response if LLM fails or is blocked.
    """
    action = decision.get("action", "WAIT")
    symbol = decision.get("symbol", "")
    timeframe = decision.get("timeframe", "")
    confidence = decision.get("confidence", 0.0)
    confirmation = decision.get("confirmation", False)
    reason = decision.get("reason") or decision.get("user_message") or "No additional details."

    return {
        "explanation": (
            f"Engine decision: {action} for {symbol} on {timeframe}. "
            f"confidence={confidence}, confirmation={confirmation}. "
            f"Reason: {reason}"
        ),
        "notes": [
            "Alex explanation was blocked or unavailable.",
            "This response is deterministic and matches engine output only.",
        ],
    }
