from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from typing import Any, Dict, Optional

from django.core.cache import cache


# ============================================================
# 1) EXECUTION PERMISSION GUARD (deterministic; engine authority)
# ============================================================

@dataclass(frozen=True)
class GuardrailResult:
    allowed: bool
    reason: str


def can_execute(
    decision: Dict[str, Any],
    *,
    auto_trade_enabled: bool,
    max_spread_points: Optional[float] = None,
    confidence_min: int = 80,
) -> GuardrailResult:
    """
    Deterministic execution permission check.
    This is NOT related to LLM text.
    """
    if not auto_trade_enabled:
        return GuardrailResult(False, "auto_trading_disabled")

    if decision.get("status") != "OK":
        return GuardrailResult(False, "decision_not_ok")

    action = str(decision.get("action", "")).upper()

    # Backward compatible: allow ENTER (older), BUY/SELL (current)
    if action not in ("ENTER", "BUY", "SELL"):
        return GuardrailResult(False, f"action_not_executable:{action}")

    if int(decision.get("confidence", 0) or 0) < int(confidence_min):
        return GuardrailResult(False, f"confidence_below_{confidence_min}")

    if decision.get("confirmation") is not True:
        return GuardrailResult(False, "confirmation_not_present")

    # Entry price is required for execution (engine authority)
    if decision.get("entry_price") is None:
        return GuardrailResult(False, "missing_entry_price")

    # Optional spread gate (only if decision.raw.spread_points exists)
    if max_spread_points is not None:
        raw = decision.get("raw") if isinstance(decision.get("raw"), dict) else {}
        spread = raw.get("spread_points")
        if spread is not None and float(spread) > float(max_spread_points):
            return GuardrailResult(False, f"spread_too_high:{spread}>{max_spread_points}")

    return GuardrailResult(True, "allowed")


# ============================================================
# 2) ALEX / LLM OUTPUT GUARD (anti-hallucination; explain-only)
# ============================================================

@dataclass(frozen=True)
class AlexOutputResult:
    ok: bool
    reason: str
    payload: Optional[Dict[str, Any]] = None


_TRADE_WORDS = re.compile(r"\b(buy|sell|long|short|entry|sl|tp|stop loss|take profit)\b", re.IGNORECASE)


def validate_alex_output(decision: Dict[str, Any], llm_text: str) -> AlexOutputResult:
    """
    Validates Alex explanation output.
    - Alex must not change the decision.
    - If action is WAIT, Alex must not output trade instructions.
    - Returns a JSON payload for frontend rendering.
    """
    if not isinstance(decision, dict) or not decision:
        return AlexOutputResult(ok=False, reason="empty_decision")

    if decision.get("status") != "OK":
        return AlexOutputResult(ok=False, reason="decision_not_ok")

    if not llm_text or not llm_text.strip():
        return AlexOutputResult(ok=False, reason="empty_llm_output")

    action = str(decision.get("action", "WAIT")).upper()
    confidence = int(decision.get("confidence", 0) or 0)

    # Hard safety rule: if WAIT, do not allow trade-language instructions
    if action == "WAIT" and _TRADE_WORDS.search(llm_text):
        return AlexOutputResult(ok=False, reason="trade_language_not_allowed_on_wait")

    payload = {
        "explanation": llm_text.strip(),
        "engine_echo": {
            "action": action,
            "confidence": confidence,
            "price": decision.get("price"),
            "reason": decision.get("reason"),
            "symbol": decision.get("symbol"),
            "timeframe": decision.get("timeframe"),
        },
        "limits": [
            "Explanation only. Engine decision is authoritative.",
            "No execution unless execution_guard.allowed == true.",
        ],
        "what_to_watch": [],
    }
    return AlexOutputResult(ok=True, reason="ok", payload=payload)


def fallback_explanation(decision: Dict[str, Any]) -> Dict[str, Any]:
    """
    Deterministic fallback payload if LLM output fails or is blocked.
    """
    return {
        "explanation": (
            f"Engine decision: {decision.get('action')} | "
            f"confidence={decision.get('confidence')} | "
            f"reason={decision.get('reason')}"
        ),
        "engine_echo": {
            "action": decision.get("action"),
            "confidence": decision.get("confidence"),
            "price": decision.get("price"),
            "reason": decision.get("reason"),
            "symbol": decision.get("symbol"),
            "timeframe": decision.get("timeframe"),
        },
        "limits": ["Alex explanation was blocked or unavailable."],
        "what_to_watch": [],
    }


# ============================================================
# 3) TRADE EXECUTION GUARD (confirm + replay protection)
# ============================================================

@dataclass(frozen=True)
class ExecutionGuardResult:
    allowed: bool
    reason: str
    fingerprint: str


class TradeExecutionGuard:
    """
    Execution guard for LIVE trades:
    - requires explicit confirmation (body or header)
    - blocks duplicates via fingerprint + cache.add (idempotent)
    """

    def __init__(self, *, min_confidence: int = 60, replay_ttl_seconds: int = 120):
        self.min_confidence = int(min_confidence)
        self.replay_ttl_seconds = int(replay_ttl_seconds)

    def check(
        self,
        *,
        decision: Dict[str, Any],
        request_data: Dict[str, Any],
        request_headers: Dict[str, str],
    ) -> ExecutionGuardResult:

        if decision.get("status") != "OK":
            return self._deny("decision_not_ok", decision)

        action = str(decision.get("action") or "").upper()
        if action not in ("BUY", "SELL", "ENTER"):
            return self._deny("action_not_trade", decision)

        confidence = int(decision.get("confidence") or 0)
        if confidence < self.min_confidence:
            return self._deny(f"low_confidence_{confidence}", decision)

        if decision.get("confirmation") is not True:
            return self._deny("decision_not_confirmed", decision)

        # explicit confirm (body or header)
        body_confirm = bool(request_data.get("confirm"))
        header_confirm = (request_headers.get("X-Confirm-Trade", "") or "").lower() in ("1", "true", "yes", "y")
        if not (body_confirm or header_confirm):
            return self._deny("missing_request_confirmation", decision)

        fp = self._fingerprint(decision)
        cache_key = f"alex_exec:{fp}"
        is_new = cache.add(cache_key, "1", timeout=self.replay_ttl_seconds)
        if not is_new:
            return ExecutionGuardResult(False, "replay_blocked_duplicate_execution", fp)

        return ExecutionGuardResult(True, "allowed", fp)

    def _deny(self, reason: str, decision: Dict[str, Any]) -> ExecutionGuardResult:
        return ExecutionGuardResult(False, reason, self._fingerprint(decision))

    @staticmethod
    def _fingerprint(decision: Dict[str, Any]) -> str:
        core = {
            "symbol": decision.get("symbol"),
            "timeframe": decision.get("timeframe"),
            "action": decision.get("action"),
            "confidence": decision.get("confidence"),
            "confirmation": decision.get("confirmation"),
            "entry_price": decision.get("entry_price"),
            "zone": (decision.get("raw") or {}).get("best_zone") if isinstance(decision.get("raw"), dict) else None,
        }
        raw = json.dumps(core, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()
