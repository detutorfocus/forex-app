import os
from typing import Optional


def _chat_new_sdk(prompt: str, model: str) -> str:
    # openai>=1.x
    from openai import OpenAI

    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    resp = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    return (resp.choices[0].message.content or "").strip()


def _chat_old_sdk(prompt: str, model: str) -> str:
    # openai<1.x
    import openai

    openai.api_key = os.getenv("OPENAI_API_KEY")
    resp = openai.ChatCompletion.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
    )
    # Old SDK returns dict-like
    return (resp["choices"][0]["message"]["content"] or "").strip()


def chat(prompt: str, model: str = "gpt-4o-mini") -> str:
    """Return plain-text completion.

    Works with both the old and new OpenAI Python SDKs.
    """
    try:
        return _chat_new_sdk(prompt, model=model)
    except Exception:
        # If the new SDK isn't installed/compatible, fall back to old.
        return _chat_old_sdk(prompt, model=model)