# ai_assistant/alex/rules.py

ACTION_AVOID = "AVOID"
ACTION_WAIT = "WAIT"
ACTION_PREPARE = "PREPARE"
ACTION_ENTER = "ENTER"

ALLOWED_ACTIONS = {ACTION_AVOID, ACTION_WAIT, ACTION_PREPARE, ACTION_ENTER}

CONFIRMATION_TYPES = {
    "ENGULFING",
    "PIN_BAR",
    "CHOCH_BOS",
    "DISPLACEMENT",
    "NONE",
}

LIQUIDITY_EVENTS = {
    "SWEPT_HIGHS",
    "SWEPT_LOWS",
    "NONE",
    "UNCLEAR",
}

BIAS_VALUES = {"BULLISH", "BEARISH", "NEUTRAL"}

PHASE_VALUES = {"RANGE", "ACCUMULATION", "EXPANSION", "DISTRIBUTION", "REVERSAL"}

VOL_VALUES = {"LOW", "NORMAL", "HIGH"}


def action_allowed_by_confidence(action: str, score: int) -> bool:
    if action == ACTION_ENTER:
        return score >= 75
    if action == ACTION_PREPARE:
        return score >= 60
    # WAIT/AVOID allowed at any score
    return True


def requires_confirmation(action: str) -> bool:
    return action == ACTION_ENTER
