# ai_assistant/alex/schemas.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class AlexResponse:
    status: str
    action: str
    symbol: str
    timeframe: str
    confidence: int
    confirmation: bool
    entry_price: Optional[float] = None
    user_message: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)


REQUIRED_TOP_KEYS = {
    "status",
    "action",
    "symbol",
    "timeframe",
    "confidence",
    "confirmation",
    "user_message",
}

ALEX_SIGNAL_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "status": {"type": "string"},
        "action": {"type": "string"},
        "symbol": {"type": "string"},
        "timeframe": {"type": "string"},
        "confidence": {"type": "integer",
                       "minimum": 0,
                       "maximum": 100,},
        "confirmation": {"type": "boolean"},
        "entry_price": {"type": ["number", "null"]},
        "user_message": {"type": "string"},
    },
    "required": [
        "status",
        "action",
        "symbol",
        "timeframe",
        "confidence",
        "confirmation",
        "entry_price",
        "user_message",
    ],
}
