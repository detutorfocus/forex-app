# ai_assistant/alex/validator.py
from __future__ import annotations
from typing import Any, Dict, Tuple

from rest_framework.templatetags.rest_framework import data

from .schemas import AlexResponse, REQUIRED_TOP_KEYS
from .rules import (
    ALLOWED_ACTIONS,
    CONFIRMATION_TYPES,
    action_allowed_by_confidence,
    requires_confirmation,
)

class AlexValidationError(Exception):
    pass


def validate_alex_payload(payload: Dict[str, Any]) -> AlexResponse:
    if not isinstance(payload, dict):
        raise AlexValidationError("Alex payload must be a JSON object.")

    missing = REQUIRED_TOP_KEYS - set(payload.keys())
    if missing:
        raise AlexValidationError(f"Missing required keys: {sorted(list(missing))}")

    status = str(payload.get("status"))
    action = str(payload.get("action"))
    symbol = str(payload.get("symbol"))
    timeframe = str(payload.get("timeframe"))


    if action not in ALLOWED_ACTIONS:
        raise AlexValidationError(f"Invalid action: {action}")

    # confidence: must be int 0..100
    confidence = payload.get("confidence")

    if not isinstance(confidence, int):
        raise AlexValidationError("confidence must be an integer.")

    if not (0 <= confidence <= 100):
        raise AlexValidationError("confidence must be between 0 and 100.")

    confirmation = payload.get("confirmation", False)

    if not isinstance(confirmation, bool):
        raise AlexValidationError("confirmation must be a boolean.")

    # HARD GATE: ENTER requires confirmation present
    if requires_confirmation(action) and confirmation is not True:
        raise AlexValidationError(
            "ENTER action is not allowed without confirmation."
        )

    # HARD GATE: ENTER must respect confidence threshold
    if not action_allowed_by_confidence(action, confidence):
        raise AlexValidationError(
            f"Action {action} not allowed for confidence {confidence}"
        )

    user_message = str(payload.get("user_message", "")).strip()
    if not user_message:
        raise AlexValidationError("user_message must be a non-empty string.")

    trade_plan = payload.get("trade_plan", {})
    entry_price = None
    if isinstance(trade_plan, dict):
        entry = trade_plan.get("entry", {})
        if isinstance(entry, dict):
            p = entry.get("price")
            if isinstance(p, (int, float)):
                entry_price = float(p)

    return AlexResponse(
        status=status,
        action=action,
        symbol=symbol,
        timeframe=timeframe,
        confidence=confidence,
        confirmation= bool(confirmation),
        entry_price=entry_price,
        user_message=user_message,
        raw=payload,
    )
