# ai_assistant/alex/wrapper.py
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Tuple

from rest_framework.templatetags.rest_framework import data

from .prompts import ALEX_SYSTEM_PROMPT, ALEX_DEVELOPER_PROMPT


class AlexLLMError(Exception):
    pass


def build_alex_messages(*, symbol: str, timeframe: str, market_payload: Dict[str, Any]) -> List[Dict[str, str]]:
    """
    Build chat messages for Alex.
    market_payload MUST be structured data produced by your market feed / stage 5 services.
    """
    user_content = {
        "request": {
            "symbol": symbol,
            "timeframe": timeframe,
            "mode": "manual_chart_analysis",
        },
        "market_payload": market_payload,
        "instructions": {
            "must_include": ["signal", "why", "entry_price_if_any", "confidence"],
            "must_not": ["guarantees", "hallucinated_levels"],
        },
        "required_response": {
            "format": "human_text_and_json",
            "json_schema_hint": "Include keys: status, action, symbol, timeframe, market_state, zones, liquidity, confirmation, trade_plan, confidence, reasoning_summary, risk_notes, next_actions, user_message"
        }
    }

    return [
        {"role": "system", "content": ALEX_SYSTEM_PROMPT.strip()},
        {"role": "developer", "content": ALEX_DEVELOPER_PROMPT.strip()},
        {"role": "user", "content": json.dumps(user_content)},
    ]

def extract_json_from_text(text: str) -> Dict[str, Any]:
    # Removes code fences and tries to locate the first JSON object
    if not text or not isinstance(text, str):
        raise ValueError("Empty Alex response.")

    cleaned = text.strip()
    cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
    cleaned = re.sub(r"\s*```$", "", cleaned).strip()
    print("DATA TYPE:", type(text), text)
    # Try direct parse first
    try:
        data = json.loads(cleaned)  # MUST be called
    except Exception:
        # Fallback: extract first {...} block
        m = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
        if not m:
            raise ValueError("No JSON object found in Alex response.")
        data = json.loads(m.group(0))  #  MUST be called

    if not isinstance(data, dict):
        raise ValueError(f"Expected JSON object, got {type(data).__name__}")

    # Backward compat mapping
    if "confidence" not in data and "confidence" in data:
        data["confidence"] = data.pop("confidence")

    if "confirmation" not in data and "confirmation" in data:
        data["confirmation"] = data.pop("confirmation")

    return data



async def call_alex_model(*, llm_client: Any, messages: List[Dict[str, str]]) -> str:
    """
    Plug in your model provider here.
    llm_client should be your own abstraction.
    This function must return the model's text response.
    """
    # Example interface (you will adapt):
    # response_text = await llm_client.chat(messages=messages, temperature=0.2)
    # return response_text
    raise NotImplementedError("Implement model call in your llm_client layer.")
