# ai_assistant/api/serializers.py
from rest_framework import serializers

class AlexAnalyzeRequestSerializer(serializers.Serializer):
    symbol = serializers.CharField()
    timeframe = serializers.CharField()
    bars = serializers.IntegerField(required=False, min_value=50, max_value=5000, default=300)

class AlexAnalyzeResponseSerializer(serializers.Serializer):
    status = serializers.CharField()
    action = serializers.CharField()
    symbol = serializers.CharField()
    timeframe = serializers.CharField()
    confidence = serializers.IntegerField()
    confirmation = serializers.BooleanField()
    entry_price = serializers.FloatField(required=False, allow_null=True)
    user_message = serializers.CharField()
    raw = serializers.JSONField()
