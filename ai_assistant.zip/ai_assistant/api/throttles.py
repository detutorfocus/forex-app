from rest_framework.response import Response
from rest_framework.views import exceptions as drf_exceptions
from rest_framework.throttling import AnonRateThrottle, UserRateThrottle

class AnalyzeRateThrottle(UserRateThrottle):
    scope = "analyze"
    scopes = ("analyze", "alex_analyze")
class ExecuteRateThrottle(UserRateThrottle):
    scope = "execute"