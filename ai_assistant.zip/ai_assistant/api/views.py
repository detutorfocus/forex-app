# ai_assistant/api/views.py
from __future__ import annotations

from dataclasses import asdict, is_dataclass

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from .serializers import AlexAnalyzeRequestSerializer
from .throttles import AnalyzeRateThrottle

from ..services.container import get_services
from ..engine.market_data import MarketDataProvider
from ..engine.zone_engine import analyze_zones

from ai_assistant.alex.explain import build_explain_prompt
from ai_assistant.alex.llm_client import chat as llm_chat
from ai_assistant.alex.guard import validate_alex_output, fallback_explanation
from ai_assistant.alex.execution_guard import check_execution_safety
from dataclasses import is_dataclass, asdict
from typing import Any, Dict


from notifications.models import (
    NotificationPreference,
    SignalEvent,
    NotificationDelivery,
)




def _safe_to_dict(decision: Any, *, timeframe: str, auto_trade_enabled: bool) -> Dict[str, Any]:
    # Convert decision to dict first
    if is_dataclass(decision):
        d = asdict(decision)
    elif hasattr(decision, "to_dict"):
        d = decision.to_dict()
    elif isinstance(decision, dict):
        d = decision
    else:
        d = {"value": str(decision)}

    # Add execution guard info
    guard = check_execution_safety(
        timeframe=timeframe,
        decision=d,
        auto_trade_enabled=auto_trade_enabled,
    )

    d.setdefault("meta", {})
    d["meta"]["execution_guard"] = {
        "allowed": guard.allowed,
        "reason": guard.reason,
        "meta": guard.meta,
    }
    d["execution_allowed"] = guard.allowed
    return d




def _get_or_create_prefs(user) -> NotificationPreference:
    prefs, _ = NotificationPreference.objects.get_or_create(user=user)
    return prefs


def _extract_levels(decision: dict) -> dict:
    """
    Normalize SL/TPs from decision if present.
    Adjust these keys to match your zone_engine output.
    """
    sl = decision.get("sl") or decision.get("stop_loss")
    tps = decision.get("tps") or decision.get("take_profits") or []
    tp1 = tps[0] if len(tps) > 0 else decision.get("tp1")
    tp2 = tps[1] if len(tps) > 1 else decision.get("tp2")
    tp3 = tps[2] if len(tps) > 2 else decision.get("tp3")
    return {"sl": sl, "tp1": tp1, "tp2": tp2, "tp3": tp3}


def _notify_user(user, *, title: str, body: str, data: dict, prefs: NotificationPreference) -> None:
    """
    Sends notifications only if allowed by preferences.
    Uses your existing notifications/services.py if present.
    """
    # Import lazily so server doesn't crash if you haven't finished services wiring
    try:
        from notifications.services import send_webpush_to_user
    except Exception:
        send_webpush_to_user = None

    try:
        from notifications.telegram import send_telegram_message  # optional
    except Exception:
        send_telegram_message = None

    # WEBPUSH
    if prefs.webpush_enabled and send_webpush_to_user:
        ok, reason = send_webpush_to_user(user=user, title=title, body=body, data=data)
        NotificationDelivery.objects.create(
            user=user,
            channel="WEBPUSH",
            title=title,
            body=body,
            data=data,
            ok=bool(ok),
            error="" if ok else str(reason),
        )

    # TELEGRAM (optional)
    if prefs.telegram_enabled and send_telegram_message:
        try:
            send_telegram_message(user=user, text=f"{title}\n{body}")
            NotificationDelivery.objects.create(
                user=user,
                channel="TELEGRAM",
                title=title,
                body=body,
                data=data,
                ok=True,
                error="",
            )
        except Exception as e:
            NotificationDelivery.objects.create(
                user=user,
                channel="TELEGRAM",
                title=title,
                body=body,
                data=data,
                ok=False,
                error=str(e),
            )


class AlexAnalyzeView(APIView):
    permission_classes = [IsAuthenticated]
    throttle_classes = [AnalyzeRateThrottle]

    def post(self, request, *args, **kwargs):
        ser = AlexAnalyzeRequestSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        user = request.user
        symbol = ser.validated_data["symbol"].strip().upper()
        timeframe = ser.validated_data["timeframe"].strip().upper()
        bars = int(ser.validated_data.get("bars", 300))

        # user-controlled: allow auto trade only when user explicitly asks
        auto_trade_enabled = bool(request.data.get("auto_trade", False))

        # MT5 + candles
        services = get_services()
        mt5 = services["mt5"]
        provider = MarketDataProvider(mt5_service=mt5)
        candles = provider.get_candles(symbol=symbol, timeframe=timeframe, bars=bars)

        # Deterministic decision
        decision_obj = analyze_zones(candles=candles, symbol=symbol, timeframe=timeframe, bars=bars)
        decision = _safe_to_dict(
            decision_obj,
            timeframe=timeframe,
            auto_trade_enabled=auto_trade_enabled,
        )

        # Explain (LLM) but never overwrite deterministic fields
        alex_block = None
        if str(decision.get("status", "")).upper() == "OK":
            try:
                prompt = build_explain_prompt(decision)
                llm_text = llm_chat(prompt, symbol=symbol, timeframe=timeframe, candles=candles)

                guard = validate_alex_output(decision, llm_text)
                if guard.ok:
                    alex_block = {"text": (llm_text or "").strip()}
                else:
                    alex_block = fallback_explanation(decision)
                    alex_block["guard_blocked_reason"] = guard.reason
            except Exception as e:
                alex_block = fallback_explanation(decision)
                alex_block["llm_error"] = str(e)

        # Execution safeguards (final gate)
        exec_guard = check_execution_safety(
            timeframe=timeframe,
            decision=decision,
            auto_trade_enabled=auto_trade_enabled,
        )
        decision["execution_guard"] = {"allowed": exec_guard.allowed, "reason": exec_guard.reason, "meta": exec_guard.meta}

        # Save signal + notify (only for BUY/SELL, and only if prefs allow)
        prefs = _get_or_create_prefs(user)
        action = str(decision.get("action", "WAIT")).upper()
        confidence = int(decision.get("confidence") or 0)

        if action in {"BUY", "SELL"}:
            levels = _extract_levels(decision)

            SignalEvent.objects.create(
                user=user,
                symbol=symbol,
                timeframe=timeframe,
                action=action,
                confidence=confidence,
                sl=levels["sl"],
                tp1=levels["tp1"],
                tp2=levels["tp2"],
                tp3=levels["tp3"],
                payload=decision,
            )

            if prefs.signal_alerts_enabled:
                title = f"Alex Signal: {symbol} {action}"
                body = f"TF: {timeframe} | Conf: {confidence}\nSL: {levels['sl']}\nTP1: {levels['tp1']} | TP2: {levels['tp2']} | TP3: {levels['tp3']}"
                _notify_user(user, title=title, body=body, data={"symbol": symbol, "timeframe": timeframe, "action": action}, prefs=prefs)

        return Response(
            {
                "decision": decision,
                "alex": alex_block,
                "prefs_locked": prefs.locked,
            },
            status=200,
        )
