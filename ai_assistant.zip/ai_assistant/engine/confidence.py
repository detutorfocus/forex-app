from __future__ import annotations
from typing import Optional
from typing import Any, Dict

def clamp(n: float, lo: float = 0.0, hi: float = 100.0) -> int:
    return int(max(lo, min(hi, n)))


def score_confidence(
    *,
    zone_strength: float,
    proximity_0_to_1: float,
    rejection_quality_0_to_1: Optional[float],
    confirmed: bool,
) -> int:
    """
    Returns 0..100
    """
    # Normalize zone strength into 0..1 (cap so it doesn't explode)
    z = min(1.0, max(0.0, zone_strength / 10.0))

    rq = float(rejection_quality_0_to_1) if rejection_quality_0_to_1 is not None else 0.0
    rq = max(0.0, min(1.0, rq))

    base = (
        (z * 35.0) +
        (proximity_0_to_1 * 35.0) +
        (rq * 20.0)
    )

    if confirmed:
        base += 10.0

    # Make low-quality situations drop harder
    if rq < 0.4:
        base -= 10.0

    return clamp(base)

def clamp(n: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, n))

def calibrate_confidence(*, decision: Dict[str, Any], confirmation_passed: bool, zone_quality: float, rejection_quality: float) -> int:
    """
    Deterministic confidence score 0-100
    Based on: zone quality, rejection quality, and whether confirmation passed.
    """

    base = 30.0
    base += zone_quality * 40.0          # up to +40
    base += rejection_quality * 20.0     # up to +20

    if confirmation_passed:
        base += 10.0
    else:
        base -= 15.0

    # Penalize if action is BUY/SELL but zones missing (shouldn't happen, but safe)
    action = decision.get("action")
    zones = decision.get("zones") or []
    if action in {"BUY", "SELL"} and not zones:
        base -= 30.0

    return int(clamp(base, 0, 100))
