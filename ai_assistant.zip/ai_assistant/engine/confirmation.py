# ai_assistant/engine/confirmation.py
from __future__ import annotations
from ai_assistant.engine.confirmation_config import FAST, MEDIUM, LONG

from dataclasses import dataclass
from typing import Any
from typing import Optional, List

# Mode names (internal)
CONFIRM_BREAK_ONLY = "break_only"
CONFIRM_REJECTION_BREAK = "rejection_break"
CONFIRM_BREAK_RETEST = "break_retest"


FAST_TFS = {"M1", "M2", "M3", "M5"}
MEDIUM_TFS = {"M10", "M15", "M30"}
LONG_TFS = {"H1", "H2", "H4", "D1", "W1", "MN1"}


def pick_confirmation_mode(timeframe: str) -> str:
    tf = (timeframe or "").upper().strip()

    if tf in FAST_TFS:
        return CONFIRM_BREAK_ONLY

    if tf in MEDIUM_TFS:
        return CONFIRM_REJECTION_BREAK

    # everything else treated as long-term by default
    return CONFIRM_BREAK_RETEST


def confirm_entry(*, timeframe: str, candles, zone, rejection) -> bool:
    """
    Auto-selects confirmation style based on timeframe.
    """
    mode = pick_confirmation_mode(timeframe)

    if mode == CONFIRM_BREAK_ONLY:
        return confirm_break_only(candles, rejection)

    if mode == CONFIRM_REJECTION_BREAK:
        return confirm_rejection_and_break(candles, rejection)

    # CONFIRM_BREAK_RETEST default
    return confirm_break_retest(candles, rejection)


# ----- Confirmation Strategies -----

def confirm_break_only(candles, rejection) -> bool:
    if not rejection or len(candles) < 2:
        return False
    last = candles[-1]

    if rejection.side == "BUY":
        return last.close > rejection.high
    if rejection.side == "SELL":
        return last.close < rejection.low
    return False


def confirm_rejection_and_break(candles, rejection, min_quality: float = 0.6) -> bool:
    if not rejection or len(candles) < 2:
        return False
    if getattr(rejection, "quality", 0.0) < min_quality:
        return False

    last = candles[-1]
    if rejection.side == "BUY":
        return last.close > rejection.high
    if rejection.side == "SELL":
        return last.close < rejection.low
    return False


def confirm_break_retest(candles, rejection, tolerance_ratio: float = 0.25) -> bool:
    if not rejection or len(candles) < 3:
        return False

    prev = candles[-2]
    last = candles[-1]

    rng = abs(rejection.high - rejection.low) or 1e-9
    tol = rng * tolerance_ratio

    if rejection.side == "BUY":
        broke = prev.close > rejection.high
        retest = abs(last.low - rejection.high) <= tol and last.close > rejection.high
        return broke and retest

    if rejection.side == "SELL":
        broke = prev.close < rejection.low
        retest = abs(last.high - rejection.low) <= tol and last.close < rejection.low
        return broke and retest

    return False

def get_tf_bucket(tf: str) -> dict:
    tf = (tf or "").upper().strip()
    if tf in {"M1","M2","M3","M5","M10","M15"}:
        return FAST
    if tf in {"M20","M30","H1","H2","H3","H4"}:
        return MEDIUM
    return LONG

# If you already have Candle/Zone/RejectionSignal types somewhere, import them:
# from ai_assistant.engine.types import Candle, Zone, RejectionSignal

FAST_TF = {"M1", "M2", "M3", "M5", "M10", "M15"}
MED_TF = {"M20", "M30", "H1", "H2", "H3", "H4"}
LONG_TF = {"H6", "H8", "H12", "D1", "W1", "MN1"}


def timeframe_bucket(tf: str) -> str:
    tf = (tf or "").upper().strip()
    if tf in FAST_TF:
        return "FAST"
    if tf in MED_TF:
        return "MEDIUM"
    return "LONG"


@dataclass
class ConfirmationConfig:
    # How strict we are before allowing BUY/SELL
    min_rejection_quality: float      # wick/body logic quality
    min_zone_quality: float           # zone strength (your engine score)
    require_break_retest: bool        # stricter for fast timeframes


def pick_confirmation_config(tf: str) -> ConfirmationConfig:
    bucket = timeframe_bucket(tf)
    if bucket == "FAST":
        return ConfirmationConfig(
            min_rejection_quality=0.75,
            min_zone_quality=0.70,
            require_break_retest=True,
        )
    if bucket == "MEDIUM":
        return ConfirmationConfig(
            min_rejection_quality=0.65,
            min_zone_quality=0.60,
            require_break_retest=False,
        )
    # LONG
    return ConfirmationConfig(
        min_rejection_quality=0.55,
        min_zone_quality=0.55,
        require_break_retest=False,
    )


def confirm_entry(*, timeframe: str, zone_quality: float, rejection_quality: float, broke_and_retested: bool) -> bool:
    cfg = pick_confirmation_config(timeframe)
    if zone_quality < cfg.min_zone_quality:
        return False
    if rejection_quality < cfg.min_rejection_quality:
        return False
    if cfg.require_break_retest and not broke_and_retested:
        return False
    return True
