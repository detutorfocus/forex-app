from __future__ import annotations

# You can tune these later without refactoring.

FAST = {
    "mode": "FAST",
    "min_rejection_quality": 0.55,
    "buffer_atr_mult": 0.10,      # close-away buffer
    "retest_tolerance_ratio": 0.30,
}

MEDIUM = {
    "mode": "MEDIUM",
    "min_rejection_quality": 0.60,
    "buffer_atr_mult": 0.12,
    "retest_tolerance_ratio": 0.25,
}

LONG = {
    "mode": "LONG",
    "min_rejection_quality": 0.65,
    "buffer_atr_mult": 0.15,
    "retest_tolerance_ratio": 0.20,
    "min_move_atr_mult": 1.00,    # long TF move-away confirmation
}
