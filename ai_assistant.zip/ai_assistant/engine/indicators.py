# ai_assistant/alex/engine/indicators.py
from __future__ import annotations
from typing import List
from .types import Candle

def true_range(curr: Candle, prev: Candle) -> float:
    return max(
        curr.high - curr.low,
        abs(curr.high - prev.close),
        abs(curr.low - prev.close),
    )

def atr(candles: List[Candle], period: int = 14) -> float:
    if len(candles) < period + 1:
        return 0.0
    trs = []
    for i in range(1, len(candles)):
        trs.append(true_range(candles[i], candles[i - 1]))
    window = trs[-period:]
    return sum(window) / float(period)

def is_pivot_high(candles: List[Candle], idx: int, left: int = 2, right: int = 2) -> bool:
    if idx - left < 0 or idx + right >= len(candles):
        return False
    h = candles[idx].high
    for i in range(idx - left, idx + right + 1):
        if i == idx:
            continue
        if candles[i].high >= h:
            return False
    return True

def is_pivot_low(candles: List[Candle], idx: int, left: int = 2, right: int = 2) -> bool:
    if idx - left < 0 or idx + right >= len(candles):
        return False
    l = candles[idx].low
    for i in range(idx - left, idx + right + 1):
        if i == idx:
            continue
        if candles[i].low <= l:
            return False
    return True
