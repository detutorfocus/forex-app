# ai_assistant/engine/market_data.py
from __future__ import annotations
from typing import List, Optional, Any

from .types import Candle
from trading.mt5.service import MT5Service  # adjust import to your actual MT5Service location


class MarketDataProvider:
    def __init__(self, mt5_service: Optional[MT5Service] = None):
        self.mt5_service = mt5_service or MT5Service()

    @staticmethod
    def _rate_value(r: Any, key: str, default=None):
        """
        MT5 returns numpy structured array rows (numpy.void).
        Access is r["open"], NOT r.get("open").
        This helper makes it safe.
        """
        try:
            return r[key]
        except Exception:
            return default

    def get_candles(self, symbol: str, timeframe: str, bars: int = 300) -> List[Candle]:
        symbol = (symbol or "").strip().upper()
        timeframe = (timeframe or "").strip().upper()
        bars = int(bars or 0)

        rates = self.mt5_service.get_symbol_rates(symbol=symbol, timeframe=timeframe, bars=bars)

        # IMPORTANT: avoid "truth value of array is ambiguous"
        raw_len = 0 if rates is None else len(rates)
        print(f"[MarketDataProvider] symbol={symbol} timeframe={timeframe} bars={bars} raw_rates_len={raw_len}",
              flush=True)

        if rates is None or raw_len == 0:
            return []

        candles: List[Candle] = []

        for r in rates:
            # supports dict OR numpy.void rows
            def v(key: str, default=0):
                # dict style
                if isinstance(r, dict):
                    return r.get(key, default)
                # numpy row style
                try:
                    return r[key]
                except Exception:
                    return default

            # tick volume naming differs sometimes
            tv = v("tick_volume", None)
            if tv is None:
                tv = v("real_volume", 0)

            candles.append(
                Candle(
                    time=int(v("time", 0)),
                    open=float(v("open", 0.0)),
                    high=float(v("high", 0.0)),
                    low=float(v("low", 0.0)),
                    close=float(v("close", 0.0)),
                    tick_volume=int(tv or 0),
                )
            )
        print("MT5 rates type:", type(rates))
        print("MT5 rates len:", 0 if rates is None else len(rates))
        print("MT5 last_error:", getattr(self.mt5_service, "last_error", None))
        print("Symbol:", symbol, "Timeframe:", timeframe, "Bars:", bars)

        print(f"[MarketDataProvider] candles_len={len(candles)}", flush=True)
        return candles
