from __future__ import annotations
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.core.settings")

import django
django.setup()
from typing import Any, Dict, List
import traceback

# --- imports from your project ---
from ai_assistant.engine.market_data import MarketDataProvider
from ai_assistant.engine.zone_engine import analyze_zones

# these may exist in your project (import if you have them)
try:
    from ai_assistant.alex.prompts import build_explain_prompt
except Exception:
    build_explain_prompt = None

try:
    from ai_assistant.alex.llm_client import chat as llm_chat
except Exception:
    llm_chat = None

try:
    from ai_assistant.alex.guardrails import validate_alex_output
except Exception:
    validate_alex_output = None

try:
    from ai_assistant.alex.execution_guard import check_execution_safety
except Exception:
    check_execution_safety = None


def _run(name: str, fn):
    try:
        out = fn()
        print(f"[PASS] {name}")
        return True, out
    except Exception as e:
        print(f"[FAIL] {name}: {e.__class__.__name__}: {e}")
        print(traceback.format_exc())
        return False, None


def run_all(symbol: str = "XAUUSD", timeframe: str = "M15", bars: int = 300) -> Dict[str, Any]:
    results: Dict[str, Any] = {"symbol": symbol, "timeframe": timeframe, "bars": bars, "tests": []}

    provider = MarketDataProvider()

    ok, candles = _run(
        "MarketDataProvider.get_candles",
        lambda: provider.get_candles(symbol=symbol, timeframe=timeframe, bars=bars),
    )
    results["tests"].append({"name": "get_candles", "ok": ok, "count": len(candles) if candles else 0})
    if not ok:
        return results

    ok, decision = _run(
        "zone_engine.analyze_zones",
        lambda: analyze_zones(candles=candles, symbol=symbol, timeframe=timeframe),
    )
    results["tests"].append({"name": "analyze_zones", "ok": ok, "status": (decision or {}).get("status")})
    if not ok:
        return results

    # LLM prompt build (optional)
    if build_explain_prompt is not None:
        ok, prompt = _run("prompts.build_explain_prompt", lambda: build_explain_prompt(decision))
        results["tests"].append({"name": "build_explain_prompt", "ok": ok, "prompt_len": len(prompt) if ok else 0})
    else:
        prompt = None
        results["tests"].append({"name": "build_explain_prompt", "ok": False, "skip": "not_found"})

    # LLM call (optional)
    if llm_chat is not None and prompt:
        ok, llm_text = _run("llm_client.chat", lambda: llm_chat(prompt))
        results["tests"].append({"name": "llm_chat", "ok": ok, "text_len": len(llm_text) if ok else 0})
    else:
        llm_text = ""
        results["tests"].append({"name": "llm_chat", "ok": False, "skip": "not_found_or_no_prompt"})

    # Guardrails validation (optional)
    if validate_alex_output is not None:
        ok, guard = _run("guardrails.validate_alex_output", lambda: validate_alex_output(decision, llm_text))
        results["tests"].append(
            {"name": "validate_alex_output", "ok": ok, "guard_ok": getattr(guard, "ok", None), "reason": getattr(guard, "reason", None)}
        )
    else:
        results["tests"].append({"name": "validate_alex_output", "ok": False, "skip": "not_found"})

    # Execution safety (optional) — DOES NOT EXECUTE TRADE
    if check_execution_safety is not None:
        ok, exec_guard = _run(
            "execution_guard.check_execution_safety",
            lambda: check_execution_safety(
                user_id=None,
                symbol=symbol,
                timeframe=timeframe,
                decision=decision,
                intent=decision.get("raw", {}).get("intent"),
            ),
        )
        results["tests"].append(
            {"name": "check_execution_safety", "ok": ok, "allowed": getattr(exec_guard, "allowed", None), "reason": getattr(exec_guard, "reason", None)}
        )
    else:
        results["tests"].append({"name": "check_execution_safety", "ok": False, "skip": "not_found"})

    return results


if __name__ == "__main__":
    out = run_all()
    print("\n=== SUMMARY ===")
    for t in out["tests"]:
        print(t)
