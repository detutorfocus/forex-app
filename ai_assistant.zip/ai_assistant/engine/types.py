# ai_assistant/alex/engine/types.py
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Literal


Side = Literal["BUY", "SELL", "NONE"]
ZoneType = Literal["DEMAND", "SUPPLY", "NONE"]

@dataclass(frozen=True)
class Candle:
    time: int
    open: float
    high: float
    low: float
    close: float
    tick_volume: int = 0

@dataclass(frozen=True)
class ZoneDecision:
    symbol: str
    timeframe: str
    bars: int

    zone_type: ZoneType
    side: Side

    confidence: int            # 0..100 (INT)
    entry_price: Optional[float]
    confirmation_required: bool

    # optional debug info (safe to expose in raw)
    meta: Dict[str, Any] = field(default_factory=dict)
