from typing import Any, Dict, List, Optional, TYPE_CHECKING

from .indicators import atr
from .zone_refined import build_zones, detect_rejection

try:
    from .types import Candle
except Exception:
    Candle = Any
if TYPE_CHECKING:
    from .types import Candle, ZoneDecision
else:
    Candle = object
    ZoneDecision = dict

# -----------------------------
# Safe access helpers (NO .get crashes)
# -----------------------------
def _as_dict(obj: Any) -> Optional[Dict[str, Any]]:
    return obj if isinstance(obj, dict) else None


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _z_level(z: Any) -> float:
    # Zone object
    if z is None:
        return 0.0
    if not isinstance(z, dict):
        for k in ("price", "level", "mid"):
            v = getattr(z, k, None)
            if v is not None:
                return float(v)

    # Dict zone
    if isinstance(z, dict):
        return float(z.get("price", z.get("level", z.get("mid", 0.0))))

    return 0.0


def _z_strength(z: Any) -> float:
    if z is None:
        return 1.0
    if not isinstance(z, dict):
        for k in ("count", "strength"):
            v = getattr(z, k, None)
            if v is not None:
                return float(v)
    if isinstance(z, dict):
        return float(z.get("count", z.get("strength", 1.0)))
    return 1.0


def _z_type(z: Any) -> str:
    if z is None:
        return "UNKNOWN"
    if not isinstance(z, dict):
        v = getattr(z, "type", None)
        if v is not None:
            return str(v).upper()
    if isinstance(z, dict):
        return str(z.get("type", "UNKNOWN")).upper()
    return "UNKNOWN"


def _latest_price(candles: List[Candle]) -> float:
    return float(candles[-1].close)


def _zone_rank(z: Any, price: float) -> tuple:
    level = _z_level(z)
    strength = _z_strength(z)
    dist = abs(price - level)
    # lower dist better; higher strength better
    return (dist, -strength)


# -----------------------------
# Rejection helpers (dict OR object)
# -----------------------------
def _rej_hit(rej: Any) -> bool:
    return bool(_get_attr(rej, "hit", False))


def _rej_tolerance(rej: Any) -> Optional[float]:
    tol = _get_attr(rej, "tolerance", None)
    try:
        return float(tol) if tol is not None else None
    except Exception:
        return None


def _rej_index(rej: Any) -> Optional[int]:
    idx = _get_attr(rej, "idx", None)
    try:
        return int(idx) if idx is not None else None
    except Exception:
        return None


# -----------------------------
# Confirmation modes (AUTO by timeframe)
# -----------------------------
FAST_TF = {"M1", "M2", "M3", "M5", "M10", "M15"}
MEDIUM_TF = {"M20", "M30", "H1", "H2", "H3", "H4"}
LONG_TF = {"H6", "H8", "H12", "D1", "W1", "MN1"}


def pick_confirmation_mode(timeframe: str) -> str:
    tf = (timeframe or "").upper().strip()
    if tf in FAST_TF:
        return "FAST"
    if tf in MEDIUM_TF:
        return "MEDIUM"
    if tf in LONG_TF:
        return "LONG"
    # default
    return "MEDIUM"


def _bullish_engulf(prev: Candle, cur: Candle) -> bool:
    # bullish engulfing: current body engulfs previous body and closes up
    return (cur.close > cur.open) and (prev.close < prev.open) and (cur.close >= prev.open) and (cur.open <= prev.close)


def _bearish_engulf(prev: Candle, cur: Candle) -> bool:
    return (cur.close < cur.open) and (prev.close > prev.open) and (cur.open >= prev.close) and (cur.close <= prev.open)


def confirm_entry(timeframe: str, candles: List[Candle], zone: Any, rejection: Any) -> bool:
    """
    Confirmation is a SECOND filter after rejection.
    It is AUTO-selected by timeframe category:
      FAST: quick close-away confirmation
      MEDIUM: engulfing confirmation near zone
      LONG: move-away by ATR confirmation
    """
    if not candles or len(candles) < 5:
        return False
    if zone is None or rejection is None:
        return False
    if not _rej_hit(rejection):
        return False

    mode = pick_confirmation_mode(timeframe)
    ztype = _z_type(zone)  # SUPPLY/DEMAND/UNKNOWN
    level = _z_level(zone)

    # tolerance fallback: ATR
    tol = _rej_tolerance(rejection)
    if tol is None or tol <= 0:
        tol = max(atr(candles, 14), 1e-6)

    last = candles[-1]
    prev = candles[-2]

    # FAST: last candle must close away from the level by a small buffer
    if mode == "FAST":
        buffer = tol * 0.10
        if ztype == "SUPPLY":
            return float(last.close) < (level - buffer)
        if ztype == "DEMAND":
            return float(last.close) > (level + buffer)
        return False

    # MEDIUM: require engulfing in the expected direction
    if mode == "MEDIUM":
        if ztype == "SUPPLY":
            return _bearish_engulf(prev, last)
        if ztype == "DEMAND":
            return _bullish_engulf(prev, last)
        return False

    # LONG: require price moved away by >= ~1 ATR from level after rejection
    # (helps avoid “tiny reaction” being treated like a confirmed entry)
    if mode == "LONG":
        move = abs(float(last.close) - level)
        return move >= tol * 1.0

    return False


# -----------------------------
# Main decision
# -----------------------------
def analyze_zones(
    symbol: str,
    timeframe: str,
    bars: int,
    candles: List[Candle],
) -> ZoneDecision:
    if not candles:
        return {
            "status": "OK",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": 0,
            "confirmation": False,
            "entry_price": None,
            "user_message": "No candles available right now.",
            "raw": {"engine": "deterministic", "reason": "no_candles"},
        }

    if len(candles) < 20:
        return {
            "status": "OK",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": 5,
            "confirmation": False,
            "entry_price": None,
            "user_message": "Not enough candles yet. Try a larger bar count.",
            "raw": {"engine": "deterministic", "reason": "not_enough_candles", "candles": len(candles)},
        }

    price = _latest_price(candles)
    zones = build_zones(candles)

    if not zones:
        return {
            "status": "OK",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": 10,
            "confirmation": False,
            "entry_price": None,
            "user_message": "No clean zones found on this timeframe.",
            "raw": {"engine": "deterministic", "reason": "no_zones"},
        }

    best = min(zones, key=lambda z: _zone_rank(z, price))
    ztype = _z_type(best)
    level = _z_level(best)

    rej = detect_rejection(candles, best)

    hit = _rej_hit(rej)

    # tolerance fallback: ATR
    tol = _rej_tolerance(rej)
    if tol is None or tol <= 0:
        tol = max(atr(candles, 14), 1e-6)

    strength = _z_strength(best)
    proximity = max(0.0, 1.0 - (abs(price - level) / (tol * 2.0)))
    confidence = int(max(0.0, min(100.0, (strength * 10.0) + (proximity * 50.0))))

    # If no rejection: WAIT
    if not hit:
        return {
            "status": "OK",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": confidence,
            "confirmation": False,
            "entry_price": None,
            "user_message": f"Zone spotted ({ztype}), waiting for a clear rejection candle.",
            "raw": {
                "engine": "deterministic",
                "best_zone": best,
                "rejection": _as_dict(rej) or {"hit": False},
                "confirmation_mode": pick_confirmation_mode(timeframe),
            },
        }

    # After rejection, require confirmation by timeframe category
    confirmed = confirm_entry(timeframe=timeframe, candles=candles, zone=best, rejection=rej)

    if not confirmed:
        return {
            "status": "OK",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": max(10, min(95, confidence)),
            "confirmation": False,
            "entry_price": None,
            "user_message": "Rejection seen, but entry confirmation is not complete yet.",
            "raw": {
                "engine": "deterministic",
                "best_zone": best,
                "rejection": _as_dict(rej) or {"hit": True},
                "confirmation_mode": pick_confirmation_mode(timeframe),
            },
        }

    # Confirmed -> direction depends on zone type
    action = "WAIT"
    if ztype == "SUPPLY":
        action = "SELL"
    elif ztype == "DEMAND":
        action = "BUY"

    return {
        "status": "OK",
        "action": action,
        "symbol": symbol,
        "timeframe": timeframe,
        "confidence": min(100, max(60, confidence)),
        "confirmation": True,
        "entry_price": price,
        "user_message": f"Entry confirmed on {pick_confirmation_mode(timeframe)} rules near {ztype}.",
        "raw": {
            "engine": "deterministic",
            "best_zone": best,
            "rejection": _as_dict(rej) or {"hit": True},
            "confirmation_mode": pick_confirmation_mode(timeframe),
        },
    }
