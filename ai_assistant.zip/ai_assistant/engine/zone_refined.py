from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Literal, Dict, Any

from .types import Candle

ZoneType = Literal["DEMAND", "SUPPLY"]

@dataclass(frozen=True)
class Zone:
    zone_type: ZoneType
    low: float
    high: float
    created_index: int
    touches: int
    strength: float  # 0..1
    meta: Dict[str, Any]

def _in_zone(price: float, z: Zone) -> bool:
    return z.low <= price <= z.high

def build_zones(candles: List[Candle], lookback: int = 150) -> List[Zone]:
    """
    Simple refined zones:
    - Find 'base' candles (small bodies) followed by impulse
    - Demand: base then strong bullish impulse
    - Supply: base then strong bearish impulse
    """
    if len(candles) < 30:
        return []

    start = max(0, len(candles) - lookback)
    zones: List[Zone] = []

    for i in range(start + 3, len(candles) - 3):
        # Define "base" as 2-3 candles with small bodies
        b1, b2 = candles[i-2], candles[i-1]
        body1 = abs(b1.close - b1.open)
        body2 = abs(b2.close - b2.open)
        rng1 = b1.high - b1.low
        rng2 = b2.high - b2.low

        if rng1 <= 0 or rng2 <= 0:
            continue

        small_base = (body1 / rng1 < 0.35) and (body2 / rng2 < 0.35)

        if not small_base:
            continue

        # Impulse candle right after base
        imp = candles[i]
        imp_body = abs(imp.close - imp.open)
        imp_rng = imp.high - imp.low
        if imp_rng <= 0:
            continue

        strong_impulse = (imp_body / imp_rng) > 0.6

        if not strong_impulse:
            continue

        base_low = min(b1.low, b2.low)
        base_high = max(b1.high, b2.high)

        # classify
        if imp.close > imp.open:  # bullish impulse => demand
            ztype: ZoneType = "DEMAND"
        else:
            ztype = "SUPPLY"

        # touches: count later
        zone = Zone(
            zone_type=ztype,
            low=float(base_low),
            high=float(base_high),
            created_index=i,
            touches=0,
            strength=0.0,
            meta={"base_index": i-1, "impulse_index": i},
        )
        zones.append(zone)

    # Compute touches + strength
    final: List[Zone] = []
    for z in zones:
        touches = 0
        for j in range(z.created_index + 1, len(candles)):
            p = candles[j].close
            if _in_zone(p, z):
                touches += 1
        # Freshness: newer zones stronger
        age = (len(candles)-1) - z.created_index
        freshness = max(0.0, min(1.0, 1.0 - (age / 120.0)))

        # Touch penalty: too many touches weakens zone
        touch_factor = max(0.0, min(1.0, 1.0 - (touches / 6.0)))

        strength = max(0.0, min(1.0, 0.65*freshness + 0.35*touch_factor))

        final.append(Zone(
            zone_type=z.zone_type,
            low=z.low,
            high=z.high,
            created_index=z.created_index,
            touches=touches,
            strength=strength,
            meta={**z.meta, "age": age, "freshness": freshness, "touch_factor": touch_factor},
        ))

    # keep top 6 strongest
    final.sort(key=lambda x: x.strength, reverse=True)
    return final[:6]

def detect_rejection(candles: List[Candle], zone: Zone) -> bool:
    """
    Rejection heuristic:
    - last candle enters zone but closes away in direction of zone bias
    """
    if len(candles) < 3:
        return False
    last = candles[-1]
    mid = (zone.low + zone.high) / 2.0

    # must have traded into zone
    traded_into = (last.low <= zone.high and last.high >= zone.low)

    if not traded_into:
        return False

    if zone.zone_type == "DEMAND":
        # bullish rejection: wick into zone and close above mid
        return last.close > mid and last.close > last.open
    else:
        # bearish rejection
        return last.close < mid and last.close < last.open

def zones_refined(candles, symbol: str, timeframe: str):
    zones = build_zones(candles)
    rejection = detect_rejection(candles, zones[0]) if zones else False
    return zones, rejection
