from __future__ import annotations
from typing import Any, Dict
from django.utils import timezone

def log_decision(
    *,
    user_id: int | None,
    symbol: str,
    timeframe: str,
    decision: Dict[str, Any],
    alex_text: str,
    meta: Dict[str, Any] | None = None,
) -> None:
    """
    Central audit log for Alex decisions.
    This is intentionally simple for now.
    Can later be persisted to DB or external log store.
    """

    record = {
        "ts": timezone.now().isoformat(),
        "user_id": user_id,
        "symbol": symbol,
        "timeframe": timeframe,
        "action": decision.get("action"),
        "confidence": decision.get("confidence"),
        "confirmation": decision.get("confirmation"),
        "meta": meta or {},
    }

    # For now: console log (safe, non-blocking)
    print("[ALEX_JOURNAL]", record)
