from __future__ import annotations
from django.conf import settings
from django.db import models


class DecisionJournal(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, null=True, blank=True)

    symbol = models.CharField(max_length=20)
    timeframe = models.CharField(max_length=10)
    action = models.CharField(max_length=10)  # BUY/SELL/WAIT
    confidence = models.PositiveIntegerField(default=0)
    confirmation = models.BooleanField(default=False)

    reason = models.TextField(blank=True, default="")
    decision = models.JSONField(default=dict)   # full deterministic decision
    alex_text = models.TextField(blank=True, default="")  # explanation (optional)
    meta = models.JSONField(default=dict)       # zones, rejection, mode, timings, etc.

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        indexes = [
            models.Index(fields=["symbol", "timeframe", "created_at"]),
            models.Index(fields=["user", "created_at"]),
        ]
