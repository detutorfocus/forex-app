from __future__ import annotations
from typing import Any, Dict, Optional
from .models import DecisionJournal


def log_decision(
    *,
    user_id: Optional[int],
    symbol: str,
    timeframe: str,
    decision: Dict[str, Any],
    alex_text: str = "",
    meta: Optional[Dict[str, Any]] = None,
) -> None:
    DecisionJournal.objects.create(
        user_id=user_id,
        symbol=symbol,
        timeframe=timeframe,
        action=str(decision.get("action", "WAIT")),
        confidence=int(decision.get("confidence", 0) or 0),
        confirmation=bool(decision.get("confirmation", False)),
        reason=str(decision.get("reason", "")),
        decision=decision,
        alex_text=alex_text or "",
        meta=meta or {},
    )
