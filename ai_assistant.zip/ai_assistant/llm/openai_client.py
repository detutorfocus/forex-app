import json
from typing import Dict, List

from openai import OpenAI
from openai import AuthenticationError, RateLimitError, BadRequestError, APIError
from requests.compat import integer_types


class OpenAILLMClient:
    def __init__(self, model: str = "gpt-5.2", reasoning_effort: str = "medium"):
        self.client = OpenAI()
        self.model = model
        self.reasoning_effort = reasoning_effort

    def _fallback(self, *, message: str, symbol: str, timeframe: str) -> str:
        payload = {
            "status": "ERROR",
            "action": "WAIT",
            "symbol": symbol,
            "timeframe": timeframe,
            "confidence": 0,
            "confirmation": False,
            "entry_price": None,
            "user_message": message,
        }
        return json.dumps(payload)

    def chat(self, messages: List[Dict[str, str]], symbol:str, timeframe:str, temperature: float = 0.2) -> str:
        # Convert your list-of-dicts messages into a single input string (simple + reliable)
        merged = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content", "")
            merged.append(f"{role.upper()}: {content}")
        input_text = "\n".join(merged).strip()

        if not input_text:
            return self._fallback(message="Empty prompt sent to LLM.", symbol=symbol, timeframe=timeframe)

        try:
            res = self.client.responses.create(
                model=self.model,
                input=input_text,
                temperature=temperature,
            )

            # ALWAYS read plain text only
            text = (res.output_text or "").strip()

            if not text:
                return self._fallback(
                    message="Empty LLM output returned.",
                    symbol=symbol,
                    timeframe=timeframe,
                )

            return text

        except AuthenticationError:
            return self._fallback(
                message="OpenAI auth failed (invalid API key).",
                symbol=symbol,
                timeframe=timeframe,
            )

        except RateLimitError:
            return self._fallback(
                message="WAIT: OpenAI quota/rate-limit reached. Please add billing or retry later.",
                symbol=symbol,
                timeframe=timeframe,
            )

        except BadRequestError as e:
            return self._fallback(
                message=f"WAIT: OpenAI bad request: {e}",
                symbol=symbol,
                timeframe=timeframe,
            )

        except APIError as e:
            return self._fallback(
                message=f"WAIT: OpenAI API error: {e}",
                symbol=symbol,
                timeframe=timeframe,
            )

        except Exception as e:
            return self._fallback(
                message=f"WAIT: {type(e).__name__}: {e}",
                symbol=symbol,
                timeframe=timeframe,
            )
