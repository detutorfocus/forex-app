from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

from django.conf import settings
from django.core.cache import cache

from .telegram import send_telegram_message
from .webpush import send_webpush_to_user


@dataclass
class NotifyResult:
    sent: bool
    reason: str


def _extract_trade_payload(decision: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Normalize the decision output into a trade payload we can notify with.
    Works whether your decision holds plan under:
      - decision["plan"]
      - decision["raw"]["plan"]
      - decision["intent"]
    """
    action = decision.get("action")
    if action not in {"BUY", "SELL"}:
        return None

    symbol = decision.get("symbol")
    timeframe = decision.get("timeframe")
    price = decision.get("price")
    confidence = decision.get("confidence", 0)

    plan = decision.get("plan") or (decision.get("raw") or {}).get("plan") or {}
    intent = decision.get("intent") or (decision.get("raw") or {}).get("intent") or {}

    entry = plan.get("entry") or intent.get("entry") or plan.get("entry_price") or intent.get("entry_price") or price
    sl = plan.get("sl") or intent.get("sl")
    tps = plan.get("tps") or intent.get("tps") or []

    # If your plan uses tp instead of list
    if not tps and plan.get("tp"):
        tps = [plan.get("tp")]

    # Guarantee TP1..TP3 shape
    tp1 = tps[0] if len(tps) > 0 else plan.get("tp1") or intent.get("tp1")
    tp2 = tps[1] if len(tps) > 1 else plan.get("tp2") or intent.get("tp2")
    tp3 = tps[2] if len(tps) > 2 else plan.get("tp3") or intent.get("tp3")

    if sl is None:
        return None  # don't alert if no SL

    return {
        "symbol": symbol,
        "timeframe": timeframe,
        "action": action,
        "confidence": confidence,
        "entry": float(entry) if entry is not None else None,
        "sl": float(sl),
        "tp1": float(tp1) if tp1 is not None else None,
        "tp2": float(tp2) if tp2 is not None else None,
        "tp3": float(tp3) if tp3 is not None else None,
        "price": float(price) if price is not None else None,
        "reason": decision.get("reason", ""),
        "confirmed": bool(decision.get("confirmation", False)),
    }


def _cooldown_key(user_id: Any, symbol: str, timeframe: str, action: str) -> str:
    return f"alex_notify_cd:{user_id}:{symbol}:{timeframe}:{action}"


def notify_user_for_decision(*, user, decision: Dict[str, Any]) -> NotifyResult:
    """
    Master notification gate.
    Uses settings:
      - ALEX_NOTIFY_MIN_CONFIDENCE
      - ALEX_NOTIFY_CONFIRMED_ONLY
      - ALEX_NOTIFY_COOLDOWN_SECONDS
      - TELEGRAM_ENABLED
    """
    if not user or not getattr(user, "is_authenticated", False):
        return NotifyResult(False, "unauthenticated_user")

    payload = _extract_trade_payload(decision)
    if not payload:
        return NotifyResult(False, "no_trade_payload")

    # Confidence gate
    min_conf = getattr(settings, "ALEX_NOTIFY_MIN_CONFIDENCE", 80)
    if (payload.get("confidence") or 0) < min_conf:
        return NotifyResult(False, "below_min_confidence")

    # Confirmed-only gate
    confirmed_only = getattr(settings, "ALEX_NOTIFY_CONFIRMED_ONLY", True)
    if confirmed_only and not payload.get("confirmed"):
        return NotifyResult(False, "not_confirmed")

    # Cooldown gate
    cooldown = int(getattr(settings, "ALEX_NOTIFY_COOLDOWN_SECONDS", 900))
    ck = _cooldown_key(user.id, payload["symbol"], payload["timeframe"], payload["action"])
    if cache.get(ck):
        return NotifyResult(False, "cooldown_active")

    # Build message
    msg = (
        f"📣 Alex Signal\n"
        f"{payload['symbol']} • {payload['timeframe']}\n"
        f"Action: {payload['action']} (Conf {payload['confidence']}%)\n"
        f"Entry: {payload['entry']}\n"
        f"SL: {payload['sl']}\n"
        f"TP1: {payload['tp1']}\n"
        f"TP2: {payload['tp2']}\n"
        f"TP3: {payload['tp3']}\n"
        f"Reason: {payload.get('reason','')}"
    )

    # Send channels
    sent_any = False

    if getattr(settings, "TELEGRAM_ENABLED", False):
        if send_telegram_message(user=user, text=msg):
            sent_any = True

    # Web push (optional)
    if send_webpush_to_user(user=user, title="Alex Signal", body=msg, data=payload):
        sent_any = True

    # Set cooldown if sent
    if sent_any:
        cache.set(ck, int(time.time()), timeout=cooldown)
        return NotifyResult(True, "sent")

    return NotifyResult(False, "no_channel_sent")
