from __future__ import annotations

import requests
from django.conf import settings


def send_telegram_message(*, user, text: str) -> bool:
    """
    Requires you store user's telegram_chat_id somewhere.
    Example: user.profile.telegram_chat_id
    """
    token = getattr(settings, "TELEGRAM_BOT_TOKEN", "")
    if not token:
        return False

    chat_id = getattr(getattr(user, "profile", None), "telegram_chat_id", None)
    if not chat_id:
        return False

    url = f"https://api.telegram.org/bot{token}/sendMessage"
    try:
        resp = requests.post(url, json={"chat_id": chat_id, "text": text}, timeout=10)
        return resp.status_code == 200
    except Exception:
        return False
