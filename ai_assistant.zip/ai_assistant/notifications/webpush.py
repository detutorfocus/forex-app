from __future__ import annotations

import json
from typing import Any, Dict
from django.conf import settings
from pywebpush import webpush, WebPushException

from .models import PushSubscription


def send_webpush_to_user(*, user, title: str, body: str, data: Dict[str, Any]) -> bool:
    subs = PushSubscription.objects.filter(user=user)
    if not subs.exists():
        return False

    payload = json.dumps({"title": title, "body": body, "data": data})

    sent_any = False
    for sub in subs:
        try:
            webpush(
                subscription_info=sub.as_webpush_dict(),
                data=payload,
                vapid_private_key=settings.VAPID_PRIVATE_KEY,
                vapid_claims=getattr(settings, "VAPID_CLAIMS", {"sub": "mailto:admin@local"}),
            )
            sent_any = True
        except WebPushException:
            # Subscription expired/bad -> remove it
            sub.delete()
        except Exception:
            pass

    return sent_any
