# ai_assistant/services/audit_bridge.py
from __future__ import annotations
from typing import Any, Dict, Optional


class AuditBridge:
    """
    Connects Alex analyses into your Stage 5 audit logging.
    You likely have an AuditLog model and a hash chaining function already.
    """

    def __init__(self, *, audit_logger: Any):
        self.audit_logger = audit_logger

    def log_alex_analysis(
        self,
        *,
        user_id: int,
        symbol: str,
        timeframe: str,
        request_payload: Dict[str, Any],
        response_payload: Dict[str, Any],
        action: str,
        confidence: int,
    ) -> None:
        # Adapt this to your stage 5 audit logging interface
        self.audit_logger.log_event(
            actor_user_id=user_id,
            event_type="ALEX_ANALYSIS",
            metadata={
                "symbol": symbol,
                "timeframe": timeframe,
                "action": action,
                "confidence": confidence,
                "request": request_payload,
                "response": response_payload,
            },
        )
