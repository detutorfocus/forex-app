# ai_assistant/services/container.py
from __future__ import annotations
from __future__ import annotations

from trading.mt5.service import MT5Service

import os
from ai_assistant.llm.openai_client import OpenAILLMClient

class NoOpAuditLogger:
    """
    Safe fallback audit logger.
    Use this until you connect the real Stage 5 audit logger/model.
    """
    def log_event(self, actor_user_id: int, event_type: str, metadata: dict):
        # Do nothing (or print if you want)
        # print(f"[AUDIT] {event_type} user={actor_user_id} meta_keys={list(metadata.keys())}")
        return

# If you haven't built LLM yet, we'll add a stub for now.
class DummyLLMClient:
    def chat(self, messages, temperature=0.2):
        # temporary response just to confirm endpoint works
        return """
        {
          "status": "OK",
          "action": "WAIT",
          "symbol": "XAUUSD",
          "timeframe": "M15",
          "market_state": {"bias":"NEUTRAL","phase":"RANGE","volatility":"NORMAL"},
          "zones": {},
          "liquidity": {"event":"UNCLEAR","level":0.0,"notes":"LLM not connected yet"},
          "confirmation": {"present": false, "type":"NONE", "notes":"No model connected"},
          "trade_plan": {"direction":"NONE","entry":{"type":"NONE","price":0.0}},
          "confidence": {"score": 50, "grade":"MEDIUM", "reasons":["LLM not connected yet"]},
          "reasoning_summary": ["Waiting for clearer confirmation."],
          "risk_notes": ["No action until model is connected."],
          "next_actions": ["Connect LLMClient next."],
          "user_message": "WAIT: Alex is ready but the LLM is not connected yet. Market read is neutral."
        }
        """


def get_services():
    print("DEBUG OPENAI_API_KEY exists?", bool(os.getenv("OPENAI_API_KEY")))
    print("DEBUG OPENAI_API_KEY startswith sk-?", str(os.getenv("OPENAI_API_KEY", "")).startswith("sk-"))
    api_key = os.getenv("OPENAI_API_KEY")

    if api_key:
        llm = OpenAILLMClient(model="gpt-5.2")
    else:
        llm = DummyLLMClient()


    return {
            "mt5": MT5Service(),
            "audit": NoOpAuditLogger(),
            "llm": llm,
        }

