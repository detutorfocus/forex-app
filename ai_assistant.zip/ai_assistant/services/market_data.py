from __future__ import annotations

from datetime import datetime
from typing import Any, List, Optional

from trading.mt5.service import MT5Service

from ..engine.types import Candle


class MarketDataProvider:
    def __init__(self, mt5_service: Optional[MT5Service] = None):
        # Use injected service when provided (tests / DI). Fall back to a default.
        self.mt5_service = mt5_service or MT5Service()

    @staticmethod
    def _rate_value(r: Any, key: str, default: Any = None) -> Any:
        """Safely extract a field from a MT5 rate row.

        MT5 typically returns a numpy structured array. Rows can be:
        - numpy.void (supports r[key] but NOT r.get)
        - dict-like (supports get)
        - simple objects (attribute access)
        """
        if r is None:
            return default

        # dict
        if isinstance(r, dict):
            return r.get(key, default)

        # numpy structured row or similar
        try:
            return r[key]  # type: ignore[index]
        except Exception:
            pass

        # object attribute
        return getattr(r, key, default)

    def get_candles(self, symbol: str, timeframe: str, bars: int) -> List[Candle]:
        symbol = (symbol or "").strip().upper()
        timeframe = (timeframe or "").strip().upper()
        bars = int(bars)

        rates = self.mt5_service.get_candles(symbol=symbol, timeframe=timeframe, bars=bars)

        # "if not rates" breaks on numpy arrays (truth value is ambiguous)
        if rates is None or len(rates) == 0:
            return []

        candles: List[Candle] = []
        for r in rates:
            t = self._rate_value(r, "time")
            if isinstance(t, (int, float)):
                t = datetime.fromtimestamp(t)

            candles.append(
                Candle(
                    time=t,
                    open=float(self._rate_value(r, "open", 0.0)),
                    high=float(self._rate_value(r, "high", 0.0)),
                    low=float(self._rate_value(r, "low", 0.0)),
                    close=float(self._rate_value(r, "close", 0.0)),
                    tick_volume=int(self._rate_value(r, "tick_volume", 0) or 0),
                )
            )

        return candles