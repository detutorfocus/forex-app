# ai_assistant/urls.py
from django.urls import path
from .api.views import AlexAnalyzeView

urlpatterns = [
    path("alex/analyze/", AlexAnalyzeView.as_view(), name="alex-analyze"),
]
