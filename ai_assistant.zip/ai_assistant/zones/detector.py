# ai_assistant/zones/detector.py
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class Zone:
    kind: str  # "SUPPLY" or "DEMAND"
    top: float
    bottom: float
    created_at: int
    base_index: int
    impulse_score: float
    touches: int
    freshness: str  # "FRESH" | "TESTED" | "OVERTOUCHED"
    timeframe: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


def _body(c: Dict[str, Any]) -> float:
    return abs(float(c["close"]) - float(c["open"]))


def _range(c: Dict[str, Any]) -> float:
    return float(c["high"]) - float(c["low"])


def _is_bull(c: Dict[str, Any]) -> bool:
    return float(c["close"]) >= float(c["open"])


def _is_bear(c: Dict[str, Any]) -> bool:
    return float(c["close"]) < float(c["open"])


def _avg(values: List[float]) -> float:
    return sum(values) / max(1, len(values))


def _count_touches(candles: List[Dict[str, Any]], top: float, bottom: float, start_idx: int) -> int:
    """
    Touch = candle range overlaps zone range after creation.
    """
    touches = 0
    for c in candles[start_idx + 1:]:
        hi = float(c["high"])
        lo = float(c["low"])
        if hi >= bottom and lo <= top:
            touches += 1
    return touches


def _freshness_from_touches(touches: int) -> str:
    if touches == 0:
        return "FRESH"
    if touches <= 2:
        return "TESTED"
    return "OVERTOUCHED"


def detect_zones(
    candles: List[Dict[str, Any]],
    timeframe: str,
    *,
    lookback: int = 220,
    impulse_mult: float = 1.8,
    base_max_candles: int = 3,
    max_zones: int = 6,
) -> List[Dict[str, Any]]:
    """
    Sniper-style zone detection using impulse/base logic.

    Candle format required:
      {"time": int, "open": float, "high": float, "low": float, "close": float, ...}

    Returns list of zones (dict).
    """
    if not candles or len(candles) < 50:
        return []

    data = candles[-lookback:] if len(candles) > lookback else candles[:]

    # baseline volatility estimate
    ranges = [_range(c) for c in data if _range(c) > 0]
    avg_range = _avg(ranges[-50:]) if len(ranges) >= 50 else _avg(ranges)

    zones: List[Zone] = []

    # Scan for impulses: a candle with range significantly > avg_range,
    # followed by continuation (next candle same direction).
    for i in range(2, len(data) - 2):
        c = data[i]
        r = _range(c)
        if avg_range <= 0:
            continue

        is_impulse = r >= (avg_range * impulse_mult)
        if not is_impulse:
            continue

        # continuation check
        c_next = data[i + 1]
        if _is_bull(c) and not _is_bull(c_next):
            continue
        if _is_bear(c) and not _is_bear(c_next):
            continue

        # Find "base" candles just before impulse:
        # Demand: last bearish (or small base) before bullish impulse
        # Supply: last bullish (or small base) before bearish impulse
        base_start = max(0, i - base_max_candles)
        base_candidates = list(range(base_start, i))

        zone_kind: Optional[str] = None
        base_idx: Optional[int] = None

        if _is_bull(c):
            zone_kind = "DEMAND"
            # Prefer the last bearish candle before impulse; fallback to smallest body candle
            bearish_idxs = [j for j in base_candidates if _is_bear(data[j])]
            if bearish_idxs:
                base_idx = bearish_idxs[-1]
            else:
                base_idx = min(base_candidates, key=lambda j: _body(data[j]))
        else:
            zone_kind = "SUPPLY"
            bullish_idxs = [j for j in base_candidates if _is_bull(data[j])]
            if bullish_idxs:
                base_idx = bullish_idxs[-1]
            else:
                base_idx = min(base_candidates, key=lambda j: _body(data[j]))

        if base_idx is None:
            continue

        base = data[base_idx]
        top = float(base["high"])
        bottom = float(base["low"])

        # impulse_score is how strong the impulse candle is vs baseline
        impulse_score = r / avg_range if avg_range > 0 else 0.0

        # Count touches after zone creation
        touches = _count_touches(data, top=top, bottom=bottom, start_idx=base_idx)
        freshness = _freshness_from_touches(touches)

        z = Zone(
            kind=zone_kind,
            top=top,
            bottom=bottom,
            created_at=int(base["time"]),
            base_index=base_idx,
            impulse_score=float(round(impulse_score, 2)),
            touches=touches,
            freshness=freshness,
            timeframe=timeframe,
        )

        zones.append(z)

    # Sort: prioritize FRESH + strong impulse
    freshness_rank = {"FRESH": 0, "TESTED": 1, "OVERTOUCHED": 2}
    zones.sort(key=lambda z: (freshness_rank.get(z.freshness, 9), -z.impulse_score))

    # Remove near-duplicate zones (overlapping heavily)
    filtered: List[Zone] = []
    for z in zones:
        duplicate = False
        for f in filtered:
            overlap = min(z.top, f.top) - max(z.bottom, f.bottom)
            if overlap > 0:
                # significant overlap => consider duplicate
                denom = max((z.top - z.bottom), (f.top - f.bottom), 1e-9)
                if (overlap / denom) > 0.6:
                    duplicate = True
                    break
        if not duplicate:
            filtered.append(z)
        if len(filtered) >= max_zones:
            break

    return [z.to_dict() for z in filtered]
